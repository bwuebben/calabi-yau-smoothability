Ancillary files for

    Smoothing Calabi-Yau threefolds with nodes and del Pezzo cone points
    Bernd Johannes Wuebben, September 2026

These files are the exact-arithmetic programs and fixed data supporting the
finite local equations, toric fans, lattice calculations, relation matrices,
and bounded census used in the paper.  The maintained public copy is

    https://github.com/bwuebben/calabi-yau-smoothability

Layout

    paper5/certificates/  Paper 5's reviewed public certificate set and JSON data
    paper5/figures/code/  standard-library checks for the degree 5, degree 8,
                          and lower-degree scope calculations
    paper4/certificates/  companion certificates used for the mixed relation
                          matrices and the 77-case classification
    src/                  shared exact toric and polytope modules
    manifests/            pinned Kreuzer-Skarke input manifest

Run commands from the root of the extracted ancillary directory.  The main
new smoothing-criterion and deformation-space checks are

    sage -python paper5/certificates/a2_simultaneous_partial_resolution.py
    sage -python paper5/certificates/dp6_nodal_partial_resolutions.py
    sage -python paper5/certificates/a2_branch_selection_counterexample.py
    sage -python paper5/certificates/branch_smoothness_inputs.py
    sage -python paper5/certificates/counterexample_deformation_germ.py
    python3 paper5/certificates/a2_counterexample_rational_replay.py
    sage -python paper5/certificates/d19_quadric_partial_resolution.py
    sage -python paper5/certificates/flop_weight_zero.py
    python3 paper5/figures/code/compute01_degree5_local.py
    python3 paper5/figures/code/compute01_degree8_local.py
    python3 paper5/figures/code/compute01_cubic_scope.py

The retained toric applications and companion relation calculations can be
reproduced with the commands in Appendix B of the paper.  Representative
standard-library checks are

    python3 paper5/certificates/locking.py
    python3 paper5/certificates/slice_rigidity.py
    python3 paper5/certificates/theoremB_class.py
    python3 paper4/certificates/relation_class.py
    python3 paper4/certificates/classification.py

Every assertion must pass.  Scripts that import Sage are run with
`sage -python`; the remaining Python programs use exact integer or rational
arithmetic for their mathematical predicates.  The finite computations do
not replace the analytic lifting, blow-down, or arbitrary-order necessity
arguments printed in the paper.

The complete database is not redistributed.  The manifest pins revision
60c0e119a03608418df538191f65da3f43b5b819 of

    https://huggingface.co/datasets/calabi-yau-data/polytopes-4d

and records every expected file's size and SHA-256 digest.  The paper uses
only the files with at most nine vertices, for the census and the 77-case
classification; explicit examples and local calculations do not use the
database.

Database verification

    src/check_ks_dataset.py       full PALP reflexivity and lattice-equivalence check
    src/test_check_ks_dataset.py  adversarial input and checkpoint tests
    src/reconcile_ks_inputs.py    saved input-name and row-count reconciliation
    output/ks_dataset_check_2026-09-09.json
    output/ks_scan_input_reconciliation_2026-09-09.json
    manifests/ks_upstream_history.json
    DATASET_CHECK.md              scope, input provenance and reproduction commands

All 473,800,776 entries in the 30 pinned files passed the lattice check.
Distinct reflexive representatives and the published classification total
establish completeness of the database copy. The original singularity
counts are not recomputed by that check. The upstream data objects have
been unchanged since February 2024; the saved scan coverage agrees with the
verified inventory. Legacy scan results did not record execution-time input
hashes. The 36-vertex file belongs to the full dataset and was checked
separately because the original scan range ended at 33 vertices.

From the extracted ancillary directory, run:

    python3 src/reconcile_ks_inputs.py

This checks the verified inventory and the census outputs included in this
paper's package. Repeating the full lattice check additionally requires
pyarrow, PALP and the input files; see DATASET_CHECK.md.
